import csv,sys,pathlib,collections,subprocess,shutil,tempfile
w=pathlib.Path(sys.argv[1])
def check(path):
    r=list(csv.DictReader(open(path)))
    if len(r)!=96: return False
    cols={'RED','GREEN','BLUE','YELLOW'}
    con=[x for x in r if x['word']==x['ink']]; inc=[x for x in r if x['word']!=x['ink']]
    if len(con)!=48 or len(inc)!=48: return False
    if any(x['condition']!=('congruent' if x['word']==x['ink'] else 'incongruent') for x in r): return False
    if collections.Counter(x['word'] for x in con)!={c:12 for c in cols}: return False
    pc=collections.Counter((x['word'],x['ink']) for x in inc)
    if len(pc)!=12 or set(pc.values())!={4}: return False
    run=1
    for a,b in zip(r,r[1:]):
        run=run+1 if a['condition']==b['condition'] else 1
        if run>=4: return False
        if a['word']==b['word']: return False
    return [int(x['trial']) for x in r]==list(range(1,97))
ok=False
try:
    ok=check(w/'trials.csv')
    if ok:
        t=pathlib.Path(tempfile.mkdtemp()); shutil.copy(w/'make_trials.py',t)
        subprocess.run([sys.executable,'make_trials.py','--seed','7'],cwd=t,timeout=60,capture_output=True)
        subprocess.run([sys.executable,'make_trials.py','--seed','7'],cwd=w,timeout=60,capture_output=True)
        ok=(t/'trials.csv').read_text()==(w/'trials.csv').read_text() and check(t/'trials.csv')
except Exception as e: print('error',e); ok=False
print('PASS' if ok else 'FAIL')
