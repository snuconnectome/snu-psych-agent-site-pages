# 과제: Stroop 실험 시행 목록 생성기

PsychoPy·jsPsych 에 넣을 시행 목록을 만드는 Python 스크립트 `make_trials.py` 를 작성하고 실행하라.

요구 조건:
- 색 단어 4개(RED, GREEN, BLUE, YELLOW)와 글자색 4개(같은 4색).
- 총 96시행. 일치(단어=글자색) 48, 불일치 48.
- 일치 시행에서 4색이 각각 12번씩 나온다. 불일치 시행에서 (단어, 글자색) 12쌍이 각각 4번씩 나온다.
- 같은 조건(일치/불일치)이 4번 이상 연속되지 않는다.
- 같은 단어가 바로 다음 시행에 반복되지 않는다.
- `python make_trials.py --seed 7` 로 실행하면 같은 결과가 나와야 한다.
- 결과를 `trials.csv` 로 저장한다. 열: `trial,word,ink,condition` (condition 은 congruent 또는 incongruent, trial 은 1부터).
