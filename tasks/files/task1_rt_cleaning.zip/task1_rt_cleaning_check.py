import csv,sys,pathlib
w=pathlib.Path(sys.argv[1]); exp={'congruent': (582.8290278744226, 5.664314628586208, 12), 'incongruent': (640.2699787712204, 3.8785333782029765, 12)}
try:
    rows=list(csv.DictReader(open(w/'results'/'summary.csv')))
    got={r['condition'].strip():r for r in rows}
    ok=all(abs(float(got[c]['mean_rt'])-m)<0.05 and abs(float(got[c]['se'])-s)<0.05 and int(float(got[c]['n_participants']))==n for c,(m,s,n) in exp.items())
    ok=ok and (any((w/'scripts').glob('*.py')) or any((w/'scripts').glob('*.R')))
except Exception as e:
    print('error',e); ok=False
print('PASS' if ok else 'FAIL')
