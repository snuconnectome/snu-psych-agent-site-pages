# 과제: 상호작용 그래프

`data/memory.csv` 는 연령 집단(younger/older) × 기억 부하(low/high) 설계의 정확률 자료다(참가자당 부하 조건 2개).

1. 집단·조건별 평균 정확률과 표준오차(표본표준편차/√n)를 구해 `results/fig_data.csv` 로 저장한다. 열: `age_group,load,mean,se,n`.
2. x축 부하(low, high 순서), 선은 연령 집단, 오차막대는 표준오차인 그래프를 `results/fig.png` 로 저장한다(가로 1200px 이상).
3. 그래프 코드를 `scripts/` 에 남긴다.
