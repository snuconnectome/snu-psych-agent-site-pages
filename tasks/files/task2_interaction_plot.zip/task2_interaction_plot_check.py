import csv,sys,pathlib,struct
w=pathlib.Path(sys.argv[1]); exp={('younger', 'low'): (0.8359, 0.016078900852719347, 20), ('younger', 'high'): (0.7227, 0.01689286675992032, 20), ('older', 'low'): (0.8337, 0.009179525271522831, 20), ('older', 'high'): (0.6151500000000001, 0.01785058969982726, 20)}
try:
    rows={(r['age_group'].strip(),r['load'].strip()):r for r in csv.DictReader(open(w/'results'/'fig_data.csv'))}
    ok=all(abs(float(rows[k]['mean'])-m)<0.001 and abs(float(rows[k]['se'])-s)<0.001 and int(float(rows[k]['n']))==n for k,(m,s,n) in exp.items())
    b=open(w/'results'/'fig.png','rb').read(24)
    ok=ok and b[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>I',b[16:20])[0]>=1200
except Exception as e: print('error',e); ok=False
print('PASS' if ok else 'FAIL')
